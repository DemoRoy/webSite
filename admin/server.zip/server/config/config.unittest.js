'use strict';

exports.sequelize = {
  dialect: 'mysql', // support: mysql, mariadb, postgres, mssql
  database: 'web-test',
  host: '127.0.0.1',
  port: 3306,
  username: "root",
  password: "TryaWcj1314",
};
