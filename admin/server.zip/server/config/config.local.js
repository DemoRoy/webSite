'use strict';

module.exports = {
	security: {
		csrf: {
      enable: false,
    },
	},
}
